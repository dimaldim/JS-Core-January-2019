Използвано е PHPSTORM + XAMPP.
